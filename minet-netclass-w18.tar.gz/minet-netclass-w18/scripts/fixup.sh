#!/bin/sh
whoami
chown root reader writer device_driver2; 
chgrp root reader writer device_driver2; 
chmod +s reader writer device_driver2
